package com.quickchat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;

/**
 * Handles messages (Part 2) and the arrays / stored-message features (Part 3).
 *
 * Master parallel arrays (same index = same message):
 * messageIDs, messageHashes, recipients, messageTexts, flags.
 * The Sent, Disregarded and Stored arrays are rebuilt from the master arrays
 * whenever a message is added or deleted, so they never go out of sync.
 */
public class Message {

    public static final String SENT = "Sent";
    public static final String STORED = "Stored";
    public static final String DISREGARD = "Disregard";

    // Part 3 required arrays
    private final ArrayList<String> sentMessages = new ArrayList<>();
    private final ArrayList<String> disregardedMessages = new ArrayList<>();
    private final ArrayList<String> storedMessages = new ArrayList<>();
    private final ArrayList<String> messageHashes = new ArrayList<>();
    private final ArrayList<String> messageIDs = new ArrayList<>();

    // Parallel arrays holding the rest of each message's details
    private final ArrayList<String> recipients = new ArrayList<>();
    private final ArrayList<String> messageTexts = new ArrayList<>();
    private final ArrayList<String> flags = new ArrayList<>();

    private int totalMessagesSent = 0;
    private final Path jsonFile;
    private final Random random = new Random();

    public Message(String jsonFilePath) {
        this.jsonFile = Paths.get(jsonFilePath);
    }

    // ------------------------------------------------------------------
    // Part 2 methods
    // ------------------------------------------------------------------

    /** Message ID must not be more than ten characters. */
    public boolean checkMessageID(String id) {
        return id != null && !id.isEmpty() && id.length() <= 10;
    }

    /** Recipient must start with an international code and have no more than ten digits after it. */
    public String checkRecipientCell(String cell) {
        if (cell != null && cell.matches("^\\+\\d{1,3}\\d{1,10}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. "
                + "Please correct the number and try again.";
    }

    /** Message may not exceed 250 characters. */
    public String checkMessageLength(String text) {
        if (text.length() <= 250) {
            return "Message ready to send.";
        }
        int over = text.length() - 250;
        return "Message exceeds 250 characters by " + over + "; please reduce the size.";
    }

    /** Randomly generates a ten-digit message ID (digit by digit). */
    public String generateMessageId() {
        String id = "";
        for (int i = 0; i < 10; i++) {
            id = id + random.nextInt(10);
        }
        return id;
    }

    /** Hash = first two digits of ID : message number : FIRSTWORDLASTWORD (all caps). */
    public String createMessageHash(String id, int messageNumber, String text) {
        String[] words = text.trim().split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        return (id.substring(0, 2) + ":" + messageNumber + ":" + first + last).toUpperCase();
    }

    /** 1 = send, 2 = disregard, 3 = store. */
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    /** Returns details of every message sent while the program is running. */
    public String printMessages() {
        return buildReport(SENT);
    }

    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    // ------------------------------------------------------------------
    // Part 3: populating the arrays
    // ------------------------------------------------------------------

    /** Adds a message with an auto-generated ID. Returns the message hash. */
    public String addMessage(String recipient, String text, String flag) {
        return addMessage(generateMessageId(), recipient, text, flag);
    }

    /** Adds a message with a supplied ID (used for developer test data). Returns the hash. */
    public String addMessage(String id, String recipient, String text, String flag) {
        String hash = createMessageHash(id, messageIDs.size(), text);
        messageIDs.add(id);
        messageHashes.add(hash);
        recipients.add(recipient);
        messageTexts.add(text);
        flags.add(flag);
        if (flag.equals(SENT)) {
            totalMessagesSent++;
        }
        rebuildArrays();
        if (flag.equals(STORED)) {
            storeMessage();
        }
        return hash;
    }

    private void rebuildArrays() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        for (int i = 0; i < flags.size(); i++) {
            if (flags.get(i).equals(SENT)) {
                sentMessages.add(messageTexts.get(i));
            } else if (flags.get(i).equals(DISREGARD)) {
                disregardedMessages.add(messageTexts.get(i));
            } else if (flags.get(i).equals(STORED)) {
                storedMessages.add(messageTexts.get(i));
            }
        }
    }

    // ------------------------------------------------------------------
    // Part 3: JSON storage (hand-written, no external library)
    // ------------------------------------------------------------------

    /** Writes every stored message to the JSON file. */
    public void storeMessage() {
        StringBuilder sb = new StringBuilder("[\n");
        boolean first = true;
        for (int i = 0; i < flags.size(); i++) {
            if (!flags.get(i).equals(STORED)) {
                continue;
            }
            if (!first) {
                sb.append(",\n");
            }
            first = false;
            sb.append("  {\"messageID\": \"").append(escape(messageIDs.get(i)))
              .append("\", \"messageHash\": \"").append(escape(messageHashes.get(i)))
              .append("\", \"recipient\": \"").append(escape(recipients.get(i)))
              .append("\", \"message\": \"").append(escape(messageTexts.get(i))).append("\"}");
        }
        sb.append("\n]\n");
        try {
            Files.write(jsonFile, sb.toString().getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.out.println("Could not write JSON file: " + e.getMessage());
        }
    }

    /** Reads the JSON file into the stored-messages arrays. Returns how many were loaded. */
    public int loadStoredMessages() {
        int loaded = 0;
        if (!Files.exists(jsonFile)) {
            return 0;
        }
        try {
            String json = new String(Files.readAllBytes(jsonFile), StandardCharsets.UTF_8);
            ArrayList<String> tokens = readJsonStrings(json);
            // each object = 4 key/value pairs = 8 strings
            for (int k = 0; k + 7 < tokens.size(); k += 8) {
                String id = tokens.get(k + 1);
                if (messageIDs.contains(id)) {
                    continue;
                }
                messageIDs.add(id);
                messageHashes.add(tokens.get(k + 3));
                recipients.add(tokens.get(k + 5));
                messageTexts.add(tokens.get(k + 7));
                flags.add(STORED);
                loaded++;
            }
        } catch (IOException e) {
            System.out.println("Could not read JSON file: " + e.getMessage());
        }
        rebuildArrays();
        return loaded;
    }

    private ArrayList<String> readJsonStrings(String json) {
        ArrayList<String> tokens = new ArrayList<>();
        int i = 0;
        while (i < json.length()) {
            if (json.charAt(i) == '"') {
                StringBuilder sb = new StringBuilder();
                i++;
                while (i < json.length() && json.charAt(i) != '"') {
                    char c = json.charAt(i);
                    if (c == '\\' && i + 1 < json.length()) {
                        i++;
                        char next = json.charAt(i);
                        sb.append(next == 'n' ? '\n' : next);
                    } else {
                        sb.append(c);
                    }
                    i++;
                }
                tokens.add(sb.toString());
            }
            i++;
        }
        return tokens;
    }

    private String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    // ------------------------------------------------------------------
    // Part 3: Stored Messages menu features
    // ------------------------------------------------------------------

    /** (a) Sender and recipient of all stored messages. */
    public String displaySenderAndRecipient(String sender) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < flags.size(); i++) {
            if (flags.get(i).equals(STORED)) {
                sb.append("Sender: ").append(sender)
                  .append(" | Recipient: ").append(recipients.get(i)).append("\n");
            }
        }
        return sb.length() == 0 ? "No stored messages." : sb.toString();
    }

    /** (b) The longest stored message. */
    public String displayLongestMessage() {
        String longest = "";
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedMessages.get(i).length() > longest.length()) {
                longest = storedMessages.get(i);
            }
        }
        return longest.isEmpty() ? "No stored messages." : longest;
    }

    /** Returns just the message text for an ID (or null if not found). */
    public String getMessageTextById(String id) {
        int index = messageIDs.indexOf(id);
        return index == -1 ? null : messageTexts.get(index);
    }

    /** (c) Search for a message ID and display the recipient and message. */
    public String searchByMessageId(String id) {
        int index = messageIDs.indexOf(id);
        if (index == -1) {
            return "Message ID not found.";
        }
        return "Recipient: " + recipients.get(index) + " | Message: " + messageTexts.get(index);
    }

    /** (d) All sent or stored messages for one recipient. */
    public ArrayList<String> searchByRecipient(String recipient) {
        ArrayList<String> found = new ArrayList<>();
        for (int i = 0; i < recipients.size(); i++) {
            boolean match = recipients.get(i).equals(recipient);
            boolean sentOrStored = flags.get(i).equals(SENT) || flags.get(i).equals(STORED);
            if (match && sentOrStored) {
                found.add(messageTexts.get(i));
            }
        }
        return found;
    }

    /** (e) Delete a stored message using its hash. */
    public String deleteByHash(String hash) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(hash) && flags.get(i).equals(STORED)) {
                String text = messageTexts.get(i);
                messageIDs.remove(i);
                messageHashes.remove(i);
                recipients.remove(i);
                messageTexts.remove(i);
                flags.remove(i);
                rebuildArrays();
                storeMessage();
                return "Message: \"" + text + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    /** (f) Full report of all stored messages. */
    public String displayStoredReport() {
        return buildReport(STORED);
    }

    /** Report of all sent messages. */
    public String displaySentReport() {
        return buildReport(SENT);
    }

    private String buildReport(String flag) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < flags.size(); i++) {
            if (flags.get(i).equals(flag)) {
                sb.append("Message ID:   ").append(messageIDs.get(i)).append("\n")
                  .append("Message Hash: ").append(messageHashes.get(i)).append("\n")
                  .append("Recipient:    ").append(recipients.get(i)).append("\n")
                  .append("Message:      ").append(messageTexts.get(i)).append("\n")
                  .append("--------------------------------------------\n");
            }
        }
        return sb.length() == 0 ? "No " + flag.toLowerCase() + " messages." : sb.toString();
    }

    // Getters used by the unit tests
    public ArrayList<String> getSentMessages() { return sentMessages; }
    public ArrayList<String> getDisregardedMessages() { return disregardedMessages; }
    public ArrayList<String> getStoredMessages() { return storedMessages; }
    public ArrayList<String> getMessageHashes() { return messageHashes; }
    public ArrayList<String> getMessageIDs() { return messageIDs; }
}
