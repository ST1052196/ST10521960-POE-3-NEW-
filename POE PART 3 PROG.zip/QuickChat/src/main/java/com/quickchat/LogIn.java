package com.quickchat;

/**
 * Registration and login (Part 1), written with static variables and
 * parameterless methods as in the student's own Part 1 code.
 */
public class LogIn {

    // Static variables (registration details)
    public static String firstName = "";
    public static String LastName = "";
    public static String userName = "";
    public static String passWord = "";
    public static String cellPhoneNumber = "";

    // Static variables (details typed in at login)
    public static String loginUserName = "";
    public static String loginPassWord = "";

    public static boolean checkUserName() { // checking user name method
        return userName != null && userName.contains("_") && userName.length() <= 5;
    }

    public static boolean checkPasswordComplexity() { // Password complexity check method
        if (passWord == null || passWord.length() < 8) { // Evaluating the password length
            return false;
        }
        String specialChars = "!@#$%^&*()\":{}|<>";
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;
        for (char c : passWord.toCharArray()) {
            if (Character.isUpperCase(c)) { // condition to evaluate uppercase character
                hasUpper = true;
            }
            if (specialChars.indexOf(c) >= 0) { // condition to check special character
                hasSpecial = true;
            }
            if (Character.isDigit(c)) { // condition to check digit
                hasDigit = true;
            }
        }
        return hasUpper && hasDigit && hasSpecial;
    }

    public static boolean checkCellPhoneNumber() { // Evaluate the phone number
        return cellPhoneNumber != null && cellPhoneNumber.startsWith("+27")
                && cellPhoneNumber.length() == 12;
    }

    public static String registerUser() { // registering the user
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains "
                    + "an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains "
                    + "at least eight characters, a capital letter, a number, and a special character.";
        }
        return "User has been registered successfully.";
    }

    /** Login succeeds only if the details entered match the registered details. */
    public static boolean loginUser() {
        return checkUserName() && checkPasswordComplexity()
                && loginUserName.equals(userName) && loginPassWord.equals(passWord);
    }

    public static String returnLoginStatus() { // login status
        if (loginUser()) {
            return "Welcome " + firstName + ", " + LastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}
