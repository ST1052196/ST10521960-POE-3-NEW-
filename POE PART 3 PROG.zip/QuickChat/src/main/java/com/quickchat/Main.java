package com.quickchat;

import java.util.ArrayList;
import java.util.Scanner;

/** Console application: registration, login, QuickChat menu and Stored Messages menu. */
public class Main {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.print("Enter your First Name: ");
        LogIn.firstName = scanner.nextLine();
        System.out.print("Enter your Last Name: ");
        LogIn.LastName = scanner.nextLine();

        // Username input and validation loop
        System.out.print("Enter your User Name: ");
        LogIn.userName = scanner.nextLine();
        while (!LogIn.checkUserName()) {
            System.out.println("Username is not correctly formatted; please ensure that your username "
                    + "contains an underscore and is no more than five characters in length.");
            System.out.print("Enter your User Name again: ");
            LogIn.userName = scanner.nextLine();
        }
        System.out.println("Username successfully captured.");

        // Password input and validation loop
        System.out.print("Enter your Password: ");
        LogIn.passWord = scanner.nextLine();
        while (!LogIn.checkPasswordComplexity()) {
            System.out.println("Password is not correctly formatted; please ensure that the password "
                    + "contains at least eight characters, a capital letter, a number, and a special character.");
            System.out.print("Enter your Password again: ");
            LogIn.passWord = scanner.nextLine();
        }
        System.out.println("Password successfully captured.");

        // Cell phone input and validation loop
        System.out.print("Enter your Cell phone number: ");
        LogIn.cellPhoneNumber = scanner.nextLine();
        while (!LogIn.checkCellPhoneNumber()) {
            System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            System.out.print("Enter your Cell phone number again: ");
            LogIn.cellPhoneNumber = scanner.nextLine();
        }
        System.out.println("Cell phone number successfully added.");
        System.out.println(LogIn.registerUser());

        // Login (repeat until successful)
        do {
            System.out.println("\n=== Login ===");
            System.out.print("Username: ");
            LogIn.loginUserName = scanner.nextLine();
            System.out.print("Password: ");
            LogIn.loginPassWord = scanner.nextLine();
            System.out.println(LogIn.returnLoginStatus());
        } while (!LogIn.loginUser());

        System.out.println("\nWelcome to QuickChat.");
        Message messages = new Message("storedMessages.json");
        int loaded = messages.loadStoredMessages();
        System.out.println(loaded + " stored message(s) loaded from file.");

        String sender = LogIn.firstName;
        int maxMessages = readInt("How many messages do you wish to enter? ");
        int entered = 0;
        

        boolean running = true;
        while (running) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            int choice = readInt("Choose an option: ");

            switch (choice) {
                case 1:
                    entered = sendMessages(messages, maxMessages, entered);
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    running = false;
                    break;
                case 4:
                    storedMessagesMenu(messages, sender);
                    break;
                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
        System.out.println("Total messages sent: " + messages.returnTotalMessages());
        System.out.println("Goodbye.");
    }

    private static int sendMessages(Message messages, int max, int entered) {
        if (entered >= max) {
            System.out.println("You have already entered all " + max + " messages.");
            return entered;
        }
        for (int i = entered; i < max; i++) {
            System.out.println("\n--- Message " + (i + 1) + " of " + max + " ---");

            String recipient;
            while (true) {
                System.out.print("Recipient cell number: ");
                recipient = scanner.nextLine();
                String check = messages.checkRecipientCell(recipient);
                System.out.println(check);
                if (check.startsWith("Cell phone number successfully")) {
                    break;
                }
            }

            String text;
            while (true) {
                System.out.print("Message (max 250 characters): ");
                text = scanner.nextLine();
                String check = messages.checkMessageLength(text);
                System.out.println(check);
                if (check.equals("Message ready to send.")) {
                    break;
                }
            }

            String id = messages.generateMessageId();
            System.out.println("Message ID generated: " + id);

            boolean decided = false;
            while (!decided) {
                System.out.println("1) Send Message  2) Disregard Message  3) Store Message to send later");
                int option = readInt("Choose: ");
                System.out.println(messages.sentMessage(option));
                if (option == 1) {
                    messages.addMessage(id, recipient, text, Message.SENT);
                    System.out.println("\nMessage details:");
                    System.out.println("Message ID:   " + id);
                    System.out.println("Message Hash: "
                            + messages.getMessageHashes().get(messages.getMessageHashes().size() - 1));
                    System.out.println("Recipient:    " + recipient);
                    System.out.println("Message:      " + text);
                    decided = true;
                } else if (option == 2) {
                    if (readInt("") == 0) {
                        messages.addMessage(id, recipient, text, Message.DISREGARD);
                        decided = true;
                    }
                } else if (option == 3) {
                    messages.addMessage(id, recipient, text, Message.STORED);
                    decided = true;
                }
            }
            entered++;
        }
        System.out.println("\nTotal messages sent: " + messages.returnTotalMessages());
        return entered;
    }

    private static void storedMessagesMenu(Message messages, String sender) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Stored Messages ---");
            System.out.println("a) Display sender and recipient of all stored messages");
            System.out.println("b) Display the longest stored message");
            System.out.println("c) Search for a message ID");
            System.out.println("d) Search for all messages stored for a recipient");
            System.out.println("e) Delete a message using its hash");
            System.out.println("f) Display report of all stored messages");
            System.out.println("g) Back to main menu");
            System.out.print("Choose: ");
            String option = scanner.nextLine().trim().toLowerCase();

            switch (option) {
                case "a":
                    System.out.println(messages.displaySenderAndRecipient(sender));
                    break;
                case "b":
                    System.out.println(messages.displayLongestMessage());
                    break;
                case "c":
                    System.out.print("Enter message ID: ");
                    System.out.println(messages.searchByMessageId(scanner.nextLine().trim()));
                    break;
                case "d":
                    System.out.print("Enter recipient number: ");
                    ArrayList<String> found = messages.searchByRecipient(scanner.nextLine().trim());
                    if (found.isEmpty()) {
                        System.out.println("No messages found for that recipient.");
                    }
                    for (String m : found) {
                        System.out.println("\"" + m + "\"");
                    }
                    break;
                case "e":
                    System.out.print("Enter message hash: ");
                    System.out.println(messages.deleteByHash(scanner.nextLine().trim().toUpperCase()));
                    break;
                case "f":
                    System.out.println(messages.displayStoredReport());
                    break;
                case "g":
                    back = true;
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    /** Reads an integer, re-asking until the input is valid. */
    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }
}
