package com.quickchat;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Part 1 unit tests (LogIn uses static variables, so each test sets them first). */
public class LoginTest {

    @BeforeEach
    void setUp() {
        LogIn.firstName = "Kyle";
        LogIn.LastName = "Smith";
        LogIn.userName = "kyl_1";
        LogIn.passWord = "Ch&&sec@ke99!";
        LogIn.cellPhoneNumber = "+27838968976";
        LogIn.loginUserName = "kyl_1";
        LogIn.loginPassWord = "Ch&&sec@ke99!";
    }

    @Test
    void usernameCorrectlyFormatted() {
        assertTrue(LogIn.checkUserName());
    }

    @Test
    void usernameIncorrectlyFormatted() {
        LogIn.userName = "kyle!!!!!!!";
        assertFalse(LogIn.checkUserName());
        assertEquals("Username is not correctly formatted; please ensure that your username contains "
                + "an underscore and is no more than five characters in length.", LogIn.registerUser());
    }

    @Test
    void passwordMeetsComplexity() {
        assertTrue(LogIn.checkPasswordComplexity());
    }

    @Test
    void passwordFailsComplexity() {
        LogIn.passWord = "password";
        assertFalse(LogIn.checkPasswordComplexity());
        assertEquals("Password is not correctly formatted; please ensure that the password contains "
                + "at least eight characters, a capital letter, a number, and a special character.",
                LogIn.registerUser());
    }

    @Test
    void cellPhoneCorrectlyFormatted() {
        assertTrue(LogIn.checkCellPhoneNumber());
    }

    @Test
    void cellPhoneIncorrectlyFormatted() {
        LogIn.cellPhoneNumber = "08966553";
        assertFalse(LogIn.checkCellPhoneNumber());
    }

    @Test
    void loginSuccessful() {
        assertTrue(LogIn.loginUser());
        assertEquals("Welcome Kyle, Smith it is great to see you again.", LogIn.returnLoginStatus());
    }

    @Test
    void loginFailed() {
        LogIn.loginPassWord = "wrong";
        assertFalse(LogIn.loginUser());
        assertEquals("Username or password incorrect, please try again.", LogIn.returnLoginStatus());
    }
}
