# QuickChat (PROG5121 PoE)

Console chat application (Parts 1-3): registration, login, sending / storing / disregarding
messages, JSON storage and the Stored Messages menu.

Run tests:  `mvn test`
Run app:    `mvn compile exec:java -Dexec.mainClass=com.quickchat.Main`
(or run `Main.java` from NetBeans / IntelliJ)

## Project structure

```
QuickChat/
├── pom.xml
├── README.md
├── .github/workflows/testJava.yml
└── src/
    ├── main/java/com/quickchat/
    │   ├── LogIn.java
    │   ├── Message.java
    │   └── Main.java
    └── test/java/com/quickchat/
        ├── LoginTest.java
        └── MessageTest.java
```

## Source code

### LogIn.java

Part 1: registration and login.

```java
package com.quickchat;

/**
 * Registration and login (Part 1), written with static variables and
 * parameterless methods as in the student's own Part 1 code.
 */
public class LogIn {

    // Static variables (registration details)
    public static String firstName = "";
    public static String LastName = "";
    public static String userName = "";
    public static String passWord = "";
    public static String cellPhoneNumber = "";

    // Static variables (details typed in at login)
    public static String loginUserName = "";
    public static String loginPassWord = "";

    public static boolean checkUserName() { // checking user name method
        return userName != null && userName.contains("_") && userName.length() <= 5;
    }

    public static boolean checkPasswordComplexity() { // Password complexity check method
        if (passWord == null || passWord.length() < 8) { // Evaluating the password length
            return false;
        }
        String specialChars = "!@#$%^&*()\":{}|<>";
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;
        for (char c : passWord.toCharArray()) {
            if (Character.isUpperCase(c)) { // condition to evaluate uppercase character
                hasUpper = true;
            }
            if (specialChars.indexOf(c) >= 0) { // condition to check special character
                hasSpecial = true;
            }
            if (Character.isDigit(c)) { // condition to check digit
                hasDigit = true;
            }
        }
        return hasUpper && hasDigit && hasSpecial;
    }

    public static boolean checkCellPhoneNumber() { // Evaluate the phone number
        return cellPhoneNumber != null && cellPhoneNumber.startsWith("+27")
                && cellPhoneNumber.length() == 12;
    }

    public static String registerUser() { // registering the user
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains "
                    + "an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains "
                    + "at least eight characters, a capital letter, a number, and a special character.";
        }
        return "User has been registered successfully.";
    }

    /** Login succeeds only if the details entered match the registered details. */
    public static boolean loginUser() {
        return checkUserName() && checkPasswordComplexity()
                && loginUserName.equals(userName) && loginPassWord.equals(passWord);
    }

    public static String returnLoginStatus() { // login status
        if (loginUser()) {
            return "Welcome " + firstName + ", " + LastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}
```

### Message.java

Parts 2 and 3: message handling, arrays, JSON storage, Stored Messages features.

```java
package com.quickchat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;

/**
 * Handles messages (Part 2) and the arrays / stored-message features (Part 3).
 *
 * Master parallel arrays (same index = same message):
 * messageIDs, messageHashes, recipients, messageTexts, flags.
 * The Sent, Disregarded and Stored arrays are rebuilt from the master arrays
 * whenever a message is added or deleted, so they never go out of sync.
 */
public class Message {

    public static final String SENT = "Sent";
    public static final String STORED = "Stored";
    public static final String DISREGARD = "Disregard";

    // Part 3 required arrays
    private final ArrayList<String> sentMessages = new ArrayList<>();
    private final ArrayList<String> disregardedMessages = new ArrayList<>();
    private final ArrayList<String> storedMessages = new ArrayList<>();
    private final ArrayList<String> messageHashes = new ArrayList<>();
    private final ArrayList<String> messageIDs = new ArrayList<>();

    // Parallel arrays holding the rest of each message's details
    private final ArrayList<String> recipients = new ArrayList<>();
    private final ArrayList<String> messageTexts = new ArrayList<>();
    private final ArrayList<String> flags = new ArrayList<>();

    private int totalMessagesSent = 0;
    private final Path jsonFile;
    private final Random random = new Random();

    public Message(String jsonFilePath) {
        this.jsonFile = Paths.get(jsonFilePath);
    }

    // ------------------------------------------------------------------
    // Part 2 methods
    // ------------------------------------------------------------------

    /** Message ID must not be more than ten characters. */
    public boolean checkMessageID(String id) {
        return id != null && !id.isEmpty() && id.length() <= 10;
    }

    /** Recipient must start with an international code and have no more than ten digits after it. */
    public String checkRecipientCell(String cell) {
        if (cell != null && cell.matches("^\\+\\d{1,3}\\d{1,10}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. "
                + "Please correct the number and try again.";
    }

    /** Message may not exceed 250 characters. */
    public String checkMessageLength(String text) {
        if (text.length() <= 250) {
            return "Message ready to send.";
        }
        int over = text.length() - 250;
        return "Message exceeds 250 characters by " + over + "; please reduce the size.";
    }

    /** Randomly generates a ten-digit message ID (digit by digit). */
    public String generateMessageId() {
        String id = "";
        for (int i = 0; i < 10; i++) {
            id = id + random.nextInt(10);
        }
        return id;
    }

    /** Hash = first two digits of ID : message number : FIRSTWORDLASTWORD (all caps). */
    public String createMessageHash(String id, int messageNumber, String text) {
        String[] words = text.trim().split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        return (id.substring(0, 2) + ":" + messageNumber + ":" + first + last).toUpperCase();
    }

    /** 1 = send, 2 = disregard, 3 = store. */
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    /** Returns details of every message sent while the program is running. */
    public String printMessages() {
        return buildReport(SENT);
    }

    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    // ------------------------------------------------------------------
    // Part 3: populating the arrays
    // ------------------------------------------------------------------

    /** Adds a message with an auto-generated ID. Returns the message hash. */
    public String addMessage(String recipient, String text, String flag) {
        return addMessage(generateMessageId(), recipient, text, flag);
    }

    /** Adds a message with a supplied ID (used for developer test data). Returns the hash. */
    public String addMessage(String id, String recipient, String text, String flag) {
        String hash = createMessageHash(id, messageIDs.size(), text);
        messageIDs.add(id);
        messageHashes.add(hash);
        recipients.add(recipient);
        messageTexts.add(text);
        flags.add(flag);
        if (flag.equals(SENT)) {
            totalMessagesSent++;
        }
        rebuildArrays();
        if (flag.equals(STORED)) {
            storeMessage();
        }
        return hash;
    }

    private void rebuildArrays() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        for (int i = 0; i < flags.size(); i++) {
            if (flags.get(i).equals(SENT)) {
                sentMessages.add(messageTexts.get(i));
            } else if (flags.get(i).equals(DISREGARD)) {
                disregardedMessages.add(messageTexts.get(i));
            } else if (flags.get(i).equals(STORED)) {
                storedMessages.add(messageTexts.get(i));
            }
        }
    }

    // ------------------------------------------------------------------
    // Part 3: JSON storage (hand-written, no external library)
    // ------------------------------------------------------------------

    /** Writes every stored message to the JSON file. */
    public void storeMessage() {
        StringBuilder sb = new StringBuilder("[\n");
        boolean first = true;
        for (int i = 0; i < flags.size(); i++) {
            if (!flags.get(i).equals(STORED)) {
                continue;
            }
            if (!first) {
                sb.append(",\n");
            }
            first = false;
            sb.append("  {\"messageID\": \"").append(escape(messageIDs.get(i)))
              .append("\", \"messageHash\": \"").append(escape(messageHashes.get(i)))
              .append("\", \"recipient\": \"").append(escape(recipients.get(i)))
              .append("\", \"message\": \"").append(escape(messageTexts.get(i))).append("\"}");
        }
        sb.append("\n]\n");
        try {
            Files.write(jsonFile, sb.toString().getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            System.out.println("Could not write JSON file: " + e.getMessage());
        }
    }

    /** Reads the JSON file into the stored-messages arrays. Returns how many were loaded. */
    public int loadStoredMessages() {
        int loaded = 0;
        if (!Files.exists(jsonFile)) {
            return 0;
        }
        try {
            String json = new String(Files.readAllBytes(jsonFile), StandardCharsets.UTF_8);
            ArrayList<String> tokens = readJsonStrings(json);
            // each object = 4 key/value pairs = 8 strings
            for (int k = 0; k + 7 < tokens.size(); k += 8) {
                String id = tokens.get(k + 1);
                if (messageIDs.contains(id)) {
                    continue;
                }
                messageIDs.add(id);
                messageHashes.add(tokens.get(k + 3));
                recipients.add(tokens.get(k + 5));
                messageTexts.add(tokens.get(k + 7));
                flags.add(STORED);
                loaded++;
            }
        } catch (IOException e) {
            System.out.println("Could not read JSON file: " + e.getMessage());
        }
        rebuildArrays();
        return loaded;
    }

    private ArrayList<String> readJsonStrings(String json) {
        ArrayList<String> tokens = new ArrayList<>();
        int i = 0;
        while (i < json.length()) {
            if (json.charAt(i) == '"') {
                StringBuilder sb = new StringBuilder();
                i++;
                while (i < json.length() && json.charAt(i) != '"') {
                    char c = json.charAt(i);
                    if (c == '\\' && i + 1 < json.length()) {
                        i++;
                        char next = json.charAt(i);
                        sb.append(next == 'n' ? '\n' : next);
                    } else {
                        sb.append(c);
                    }
                    i++;
                }
                tokens.add(sb.toString());
            }
            i++;
        }
        return tokens;
    }

    private String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    // ------------------------------------------------------------------
    // Part 3: Stored Messages menu features
    // ------------------------------------------------------------------

    /** (a) Sender and recipient of all stored messages. */
    public String displaySenderAndRecipient(String sender) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < flags.size(); i++) {
            if (flags.get(i).equals(STORED)) {
                sb.append("Sender: ").append(sender)
                  .append(" | Recipient: ").append(recipients.get(i)).append("\n");
            }
        }
        return sb.length() == 0 ? "No stored messages." : sb.toString();
    }

    /** (b) The longest stored message. */
    public String displayLongestMessage() {
        String longest = "";
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedMessages.get(i).length() > longest.length()) {
                longest = storedMessages.get(i);
            }
        }
        return longest.isEmpty() ? "No stored messages." : longest;
    }

    /** Returns just the message text for an ID (or null if not found). */
    public String getMessageTextById(String id) {
        int index = messageIDs.indexOf(id);
        return index == -1 ? null : messageTexts.get(index);
    }

    /** (c) Search for a message ID and display the recipient and message. */
    public String searchByMessageId(String id) {
        int index = messageIDs.indexOf(id);
        if (index == -1) {
            return "Message ID not found.";
        }
        return "Recipient: " + recipients.get(index) + " | Message: " + messageTexts.get(index);
    }

    /** (d) All sent or stored messages for one recipient. */
    public ArrayList<String> searchByRecipient(String recipient) {
        ArrayList<String> found = new ArrayList<>();
        for (int i = 0; i < recipients.size(); i++) {
            boolean match = recipients.get(i).equals(recipient);
            boolean sentOrStored = flags.get(i).equals(SENT) || flags.get(i).equals(STORED);
            if (match && sentOrStored) {
                found.add(messageTexts.get(i));
            }
        }
        return found;
    }

    /** (e) Delete a stored message using its hash. */
    public String deleteByHash(String hash) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(hash) && flags.get(i).equals(STORED)) {
                String text = messageTexts.get(i);
                messageIDs.remove(i);
                messageHashes.remove(i);
                recipients.remove(i);
                messageTexts.remove(i);
                flags.remove(i);
                rebuildArrays();
                storeMessage();
                return "Message: \"" + text + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    /** (f) Full report of all stored messages. */
    public String displayStoredReport() {
        return buildReport(STORED);
    }

    /** Report of all sent messages. */
    public String displaySentReport() {
        return buildReport(SENT);
    }

    private String buildReport(String flag) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < flags.size(); i++) {
            if (flags.get(i).equals(flag)) {
                sb.append("Message ID:   ").append(messageIDs.get(i)).append("\n")
                  .append("Message Hash: ").append(messageHashes.get(i)).append("\n")
                  .append("Recipient:    ").append(recipients.get(i)).append("\n")
                  .append("Message:      ").append(messageTexts.get(i)).append("\n")
                  .append("--------------------------------------------\n");
            }
        }
        return sb.length() == 0 ? "No " + flag.toLowerCase() + " messages." : sb.toString();
    }

    // Getters used by the unit tests
    public ArrayList<String> getSentMessages() { return sentMessages; }
    public ArrayList<String> getDisregardedMessages() { return disregardedMessages; }
    public ArrayList<String> getStoredMessages() { return storedMessages; }
    public ArrayList<String> getMessageHashes() { return messageHashes; }
    public ArrayList<String> getMessageIDs() { return messageIDs; }
}
```

### Main.java

Console application: registration, login, QuickChat menu and Stored Messages menu.

```java
package com.quickchat;

import java.util.ArrayList;
import java.util.Scanner;

/** Console application: registration, login, QuickChat menu and Stored Messages menu. */
public class Main {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.print("Enter your First Name: ");
        LogIn.firstName = scanner.nextLine();
        System.out.print("Enter your Last Name: ");
        LogIn.LastName = scanner.nextLine();

        // Username input and validation loop
        System.out.print("Enter your User Name: ");
        LogIn.userName = scanner.nextLine();
        while (!LogIn.checkUserName()) {
            System.out.println("Username is not correctly formatted; please ensure that your username "
                    + "contains an underscore and is no more than five characters in length.");
            System.out.print("Enter your User Name again: ");
            LogIn.userName = scanner.nextLine();
        }
        System.out.println("Username successfully captured.");

        // Password input and validation loop
        System.out.print("Enter your Password: ");
        LogIn.passWord = scanner.nextLine();
        while (!LogIn.checkPasswordComplexity()) {
            System.out.println("Password is not correctly formatted; please ensure that the password "
                    + "contains at least eight characters, a capital letter, a number, and a special character.");
            System.out.print("Enter your Password again: ");
            LogIn.passWord = scanner.nextLine();
        }
        System.out.println("Password successfully captured.");

        // Cell phone input and validation loop
        System.out.print("Enter your Cell phone number: ");
        LogIn.cellPhoneNumber = scanner.nextLine();
        while (!LogIn.checkCellPhoneNumber()) {
            System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            System.out.print("Enter your Cell phone number again: ");
            LogIn.cellPhoneNumber = scanner.nextLine();
        }
        System.out.println("Cell phone number successfully added.");
        System.out.println(LogIn.registerUser());

        // Login (repeat until successful)
        do {
            System.out.println("\n=== Login ===");
            System.out.print("Username: ");
            LogIn.loginUserName = scanner.nextLine();
            System.out.print("Password: ");
            LogIn.loginPassWord = scanner.nextLine();
            System.out.println(LogIn.returnLoginStatus());
        } while (!LogIn.loginUser());

        System.out.println("\nWelcome to QuickChat.");
        Message messages = new Message("storedMessages.json");
        int loaded = messages.loadStoredMessages();
        System.out.println(loaded + " stored message(s) loaded from file.");

        String sender = LogIn.firstName;
        int maxMessages = readInt("How many messages do you wish to enter? ");
        int entered = 0;
        

        boolean running = true;
        while (running) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            int choice = readInt("Choose an option: ");

            switch (choice) {
                case 1:
                    entered = sendMessages(messages, maxMessages, entered);
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    running = false;
                    break;
                case 4:
                    storedMessagesMenu(messages, sender);
                    break;
                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
        System.out.println("Total messages sent: " + messages.returnTotalMessages());
        System.out.println("Goodbye.");
    }

    private static int sendMessages(Message messages, int max, int entered) {
        if (entered >= max) {
            System.out.println("You have already entered all " + max + " messages.");
            return entered;
        }
        for (int i = entered; i < max; i++) {
            System.out.println("\n--- Message " + (i + 1) + " of " + max + " ---");

            String recipient;
            while (true) {
                System.out.print("Recipient cell number: ");
                recipient = scanner.nextLine();
                String check = messages.checkRecipientCell(recipient);
                System.out.println(check);
                if (check.startsWith("Cell phone number successfully")) {
                    break;
                }
            }

            String text;
            while (true) {
                System.out.print("Message (max 250 characters): ");
                text = scanner.nextLine();
                String check = messages.checkMessageLength(text);
                System.out.println(check);
                if (check.equals("Message ready to send.")) {
                    break;
                }
            }

            String id = messages.generateMessageId();
            System.out.println("Message ID generated: " + id);

            boolean decided = false;
            while (!decided) {
                System.out.println("1) Send Message  2) Disregard Message  3) Store Message to send later");
                int option = readInt("Choose: ");
                System.out.println(messages.sentMessage(option));
                if (option == 1) {
                    messages.addMessage(id, recipient, text, Message.SENT);
                    System.out.println("\nMessage details:");
                    System.out.println("Message ID:   " + id);
                    System.out.println("Message Hash: "
                            + messages.getMessageHashes().get(messages.getMessageHashes().size() - 1));
                    System.out.println("Recipient:    " + recipient);
                    System.out.println("Message:      " + text);
                    decided = true;
                } else if (option == 2) {
                    if (readInt("") == 0) {
                        messages.addMessage(id, recipient, text, Message.DISREGARD);
                        decided = true;
                    }
                } else if (option == 3) {
                    messages.addMessage(id, recipient, text, Message.STORED);
                    decided = true;
                }
            }
            entered++;
        }
        System.out.println("\nTotal messages sent: " + messages.returnTotalMessages());
        return entered;
    }

    private static void storedMessagesMenu(Message messages, String sender) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Stored Messages ---");
            System.out.println("a) Display sender and recipient of all stored messages");
            System.out.println("b) Display the longest stored message");
            System.out.println("c) Search for a message ID");
            System.out.println("d) Search for all messages stored for a recipient");
            System.out.println("e) Delete a message using its hash");
            System.out.println("f) Display report of all stored messages");
            System.out.println("g) Back to main menu");
            System.out.print("Choose: ");
            String option = scanner.nextLine().trim().toLowerCase();

            switch (option) {
                case "a":
                    System.out.println(messages.displaySenderAndRecipient(sender));
                    break;
                case "b":
                    System.out.println(messages.displayLongestMessage());
                    break;
                case "c":
                    System.out.print("Enter message ID: ");
                    System.out.println(messages.searchByMessageId(scanner.nextLine().trim()));
                    break;
                case "d":
                    System.out.print("Enter recipient number: ");
                    ArrayList<String> found = messages.searchByRecipient(scanner.nextLine().trim());
                    if (found.isEmpty()) {
                        System.out.println("No messages found for that recipient.");
                    }
                    for (String m : found) {
                        System.out.println("\"" + m + "\"");
                    }
                    break;
                case "e":
                    System.out.print("Enter message hash: ");
                    System.out.println(messages.deleteByHash(scanner.nextLine().trim().toUpperCase()));
                    break;
                case "f":
                    System.out.println(messages.displayStoredReport());
                    break;
                case "g":
                    back = true;
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    /** Reads an integer, re-asking until the input is valid. */
    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }
}
```

## Unit tests

### LoginTest.java

Unit tests for registration and login.

```java
package com.quickchat;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Part 1 unit tests (LogIn uses static variables, so each test sets them first). */
public class LoginTest {

    @BeforeEach
    void setUp() {
        LogIn.firstName = "Kyle";
        LogIn.LastName = "Smith";
        LogIn.userName = "kyl_1";
        LogIn.passWord = "Ch&&sec@ke99!";
        LogIn.cellPhoneNumber = "+27838968976";
        LogIn.loginUserName = "kyl_1";
        LogIn.loginPassWord = "Ch&&sec@ke99!";
    }

    @Test
    void usernameCorrectlyFormatted() {
        assertTrue(LogIn.checkUserName());
    }

    @Test
    void usernameIncorrectlyFormatted() {
        LogIn.userName = "kyle!!!!!!!";
        assertFalse(LogIn.checkUserName());
        assertEquals("Username is not correctly formatted; please ensure that your username contains "
                + "an underscore and is no more than five characters in length.", LogIn.registerUser());
    }

    @Test
    void passwordMeetsComplexity() {
        assertTrue(LogIn.checkPasswordComplexity());
    }

    @Test
    void passwordFailsComplexity() {
        LogIn.passWord = "password";
        assertFalse(LogIn.checkPasswordComplexity());
        assertEquals("Password is not correctly formatted; please ensure that the password contains "
                + "at least eight characters, a capital letter, a number, and a special character.",
                LogIn.registerUser());
    }

    @Test
    void cellPhoneCorrectlyFormatted() {
        assertTrue(LogIn.checkCellPhoneNumber());
    }

    @Test
    void cellPhoneIncorrectlyFormatted() {
        LogIn.cellPhoneNumber = "08966553";
        assertFalse(LogIn.checkCellPhoneNumber());
    }

    @Test
    void loginSuccessful() {
        assertTrue(LogIn.loginUser());
        assertEquals("Welcome Kyle, Smith it is great to see you again.", LogIn.returnLoginStatus());
    }

    @Test
    void loginFailed() {
        LogIn.loginPassWord = "wrong";
        assertFalse(LogIn.loginUser());
        assertEquals("Username or password incorrect, please try again.", LogIn.returnLoginStatus());
    }
}
```

### MessageTest.java

Unit tests for messages and Stored Messages features.

```java
package com.quickchat;

import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Part 2 and Part 3 unit tests. */
public class MessageTest {

    // Fixed IDs so the tests are repeatable (developer entry of the test data)
    private static final String ID1 = "1011111111";
    private static final String ID2 = "2022222222";
    private static final String ID3 = "3033333333";
    private static final String ID4 = "4044444444";
    private static final String ID5 = "5055555555";

    private static final String M1 = "Did you get the cake?";
    private static final String M2 = "Where are you? You are late! I have asked you to be on time.";
    private static final String M3 = "Yohoooo, I am at your gate.";
    private static final String M4 = "It is dinner time!";
    private static final String M5 = "Ok, I am leaving without you.";

    private Message messages;

    /** Developer entry of the Part 3 test data (messages 1-5), using a temporary JSON file. */
    @BeforeEach
    void setUp() throws IOException {
        File temp = File.createTempFile("quickchat", ".json");
        temp.deleteOnExit();
        messages = new Message(temp.getAbsolutePath());
        messages.addMessage(ID1, "+27834557896", M1, Message.SENT);
        messages.addMessage(ID2, "+27838884567", M2, Message.STORED);
        messages.addMessage(ID3, "+27834484567", M3, Message.DISREGARD);
        messages.addMessage(ID4, "0838884567", M4, Message.SENT);
        messages.addMessage(ID5, "+27838884567", M5, Message.STORED);
    }

    // ---------------- Part 2 tests ----------------

    @Test
    void messageLengthSuccess() {
        assertEquals("Message ready to send.", messages.checkMessageLength(M1));
    }

    @Test
    void messageLengthFailure() {
        String longText = "a".repeat(260);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.",
                messages.checkMessageLength(longText));
    }

    @Test
    void recipientNumberSuccessAndFailure() {
        assertEquals("Cell phone number successfully captured.",
                messages.checkRecipientCell("+27718693002"));
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. "
                + "Please correct the number and try again.", messages.checkRecipientCell("08575975889"));
    }

    @Test
    void messageHashIsCorrect() {
        // Test case 1 from Part 2
        assertEquals("00:0:HITONIGHT",
                messages.createMessageHash("0012345678", 0, "Hi Mike, can you join us for dinner tonight?"));
        assertEquals("00:1:HIPAYMENT",
                messages.createMessageHash("0098765432", 1, "Hi Keegan, did you receive the payment?"));
    }

    @Test
    void messageIdIsCreated() {
        String id = messages.generateMessageId();
        assertTrue(messages.checkMessageID(id));
        assertEquals(10, id.length());
    }

    @Test
    void sentMessageOptions() {
        assertEquals("Message successfully sent.", messages.sentMessage(1));
        assertEquals("Press 0 to delete the message.", messages.sentMessage(2));
        assertEquals("Message successfully stored.", messages.sentMessage(3));
    }

    @Test
    void totalMessagesSentIsCounted() {
        assertEquals(2, messages.returnTotalMessages());
    }

    // ---------------- Part 3 tests ----------------

    @Test
    void sentMessagesArrayCorrectlyPopulated() {
        assertEquals(Arrays.asList("Did you get the cake?", "It is dinner time!"),
                messages.getSentMessages());
    }

    @Test
    void disregardedAndStoredArraysPopulated() {
        assertEquals(Arrays.asList(M3), messages.getDisregardedMessages());
        assertEquals(Arrays.asList(M2, M5), messages.getStoredMessages());
        assertEquals(5, messages.getMessageHashes().size());
        assertEquals(5, messages.getMessageIDs().size());
    }

    @Test
    void displayLongestMessage() {
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                messages.displayLongestMessage());
    }

    @Test
    void searchForMessageId() {
        assertEquals("It is dinner time!", messages.getMessageTextById(ID4));
        assertEquals("Recipient: 0838884567 | Message: It is dinner time!",
                messages.searchByMessageId(ID4));
        assertEquals("Message ID not found.", messages.searchByMessageId("9999999999"));
    }

    @Test
    void searchMessagesForRecipient() {
        assertEquals(Arrays.asList("Where are you? You are late! I have asked you to be on time.",
                "Ok, I am leaving without you."), messages.searchByRecipient("+27838884567"));
    }

    @Test
    void deleteMessageUsingHash() {
        String hash = messages.getMessageHashes().get(1); // Test message 2
        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time.\" "
                + "successfully deleted.", messages.deleteByHash(hash));
        assertEquals(Arrays.asList(M5), messages.getStoredMessages());
        assertEquals("Message hash not found.", messages.deleteByHash(hash));
    }

    @Test
    void displayReportShowsHashRecipientAndMessage() {
        String report = messages.displaySentReport();
        assertTrue(report.contains(messages.getMessageHashes().get(0)));
        assertTrue(report.contains("+27834557896"));
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("0838884567"));
        assertTrue(report.contains("It is dinner time!"));
    }

    @Test
    void storedMessagesAreWrittenToAndReadFromJson() throws IOException {
        File temp = File.createTempFile("quickchat-read", ".json");
        temp.deleteOnExit();
        Message writer = new Message(temp.getAbsolutePath());
        writer.addMessage(ID2, "+27838884567", M2, Message.STORED);
        writer.addMessage(ID5, "+27838884567", M5, Message.STORED);

        Message reader = new Message(temp.getAbsolutePath());
        assertEquals(2, reader.loadStoredMessages());
        assertEquals(Arrays.asList(M2, M5), reader.getStoredMessages());
    }
}
```
